URG Viewer
http://sourceforge.net/apps/trac/urgwidget/wiki/UrgViewer

- About
  * Application tha can be used as a normal data display tool.
  * Can record and reproduce URG data.

- License
  * GPL

- Requirements
  * boost (>=1.33.1)
  * Qt (>=4.5.0)

- Options
  * Available options
    * -i -- Display intensity data
    * -r -- Record data
    * -p -- Reproduced recorded data

- Contact
  - urgwidget-users@lists.sourceforge.net
  - Satofumi KAMIMURA <satofumi@users.sourceforge.jp>
