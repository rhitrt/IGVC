v1.2 10/19/2011
---------------
- Fixed Encoder counter on single channel SDC2130/50
- improved speed capture accuracy in SDC2130/50

v1.2 09/07/2011
---------------
- Added AIC and PIC queries

v1.2 09/01/2011
---------------
- Added Ramp preload command !RMP

v1.2 08/24/2011
---------------
- Corrected Encoder enable at startup on SDC2130

v1.2 08/12/2011
---------------
- Corrected Short Circuit detect on MDC2250

v1.2 08/12/2011
---------------
- Corrected Short Circuit release bug
- Corrected controller names
- Changed default short circuit threshold to 1

v1.2 08/01/2011
---------------
- Fixed pulse capture on RCIN1 on MDC2250
- Beta RC Output feature on MDC2250

v1.2 07/24/2011
---------------
- Disable Ain4 and Pin2 default in single channel SDC2130

v1.2 07/24/2011
---------------
- Fixed SDC2130 Encoder bug

v1.2 07/15/2011
---------------
- Fixed SDC2130 RC input 5

v1.2 07/09/2011
---------------
- Fixed SDC2130 bug with pulse capture
- Fixed LED status on digital output
- Single channel amps measure on MDC2250 and HDC2450
- Amps lim raise to 150A/300A on HDC2450

v1.2 05/08/2011
---------------
- BL Hall speed capture on HDC


v1.2 03/30/2011
---------------
- Fixed Mixed mode in Closed Loop speed control
- Changed to latest StdPeriph & USB libraries

v1.2 03/20/2011
---------------
- Added single channel support on SDC2130/60
- Improved Encoder capture on single channel SDC2130/50

v1.2 03/06/2011
---------------
- Fixed MicroBasic large script size bug

v1.2 02/20/2011
---------------
- Chained EncPos motions

v1.2 02/08/2011
---------------
- Fixes HDC2450S CPLD reporting

v1.2 02/03/2011
---------------
- Changed Soft Encoder 2 Pinout
- Fixed closed loop error

v1.2 02/02/2011
---------------
- Fixed MBL amps offset

v1.2 01/16/2011
---------------
- Assembly version of softencoder
- Enable/Disable softencoder

v1.2 01/14/2011
---------------
- Speed Capture on RCB100
- Spektrum Radio support added

v1.2 01/05/2011
---------------
- Fixed _DIN getvalue
- Added TTL USART on RCB100
- Dual BLDC Speed fix
- Added softencoder
- BLDC negative speed fix
- RCB100 & RCB400 pulse capture